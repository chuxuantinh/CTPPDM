ENTROPY_NAME = 'entropy'
MAXOPERATOR_NAME = 'maxOPerator'

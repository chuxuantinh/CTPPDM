## README
This is the implementation of differential private decision tree algorithm for data mining.

### Usage:   
Install Pycharm(highly recommended!)   
This program can be run with Python3.6.    
Run main.py to see the output tree structure, and the classification accuracy for test data using this decision tree. 

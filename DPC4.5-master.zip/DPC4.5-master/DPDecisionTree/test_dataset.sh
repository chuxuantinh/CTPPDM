#!/usr/bin/env bash
python main.py -f 'car'
python main.py -f 'adult2'
python main.py -f 'example'
python main.py -f 'transfusion'
